package com.example.trainingfragment;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.viewpager.widget.ViewPager;
import com.google.android.material.tabs.TabLayout;

public class AppInformationActivity extends AppCompatActivity {

    private TabLayout tabLayout;
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_information);

        loadView();
    }

    private void loadView() {
        tabLayout = findViewById(R.id.tabs_layout);
        viewPager = findViewById(R.id.view_pager);
    }

    private void setupViewPager() {
        ViewPagerAdapter
    }
}
