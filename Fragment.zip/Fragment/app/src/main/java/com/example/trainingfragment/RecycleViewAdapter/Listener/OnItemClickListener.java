package com.example.trainingfragment.RecycleViewAdapter.Listener;

import com.example.trainingfragment.models.SettingModel;

public interface OnItemClickListener {
    void onItemClickListener(SettingModel item);
}
