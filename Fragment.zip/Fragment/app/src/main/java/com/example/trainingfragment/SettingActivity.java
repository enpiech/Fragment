package com.example.trainingfragment;

import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import android.content.Intent;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.OnItemTouchListener;
import com.example.trainingfragment.RecycleViewAdapter.Listener.OnItemClickListener;
import com.example.trainingfragment.RecycleViewAdapter.MySettingRecyclerViewAdapter;
import com.example.trainingfragment.dummy.DummyContent.DummyItem;
import com.example.trainingfragment.dummy.SettingContent;
import com.example.trainingfragment.models.SettingModel;

public class SettingActivity extends AppCompatActivity implements OnItemClickListener {
    private RecyclerView lstSetting;

    private MySettingRecyclerViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        loadView();
    }

    private void loadView() {
        lstSetting = findViewById(R.id.lst_setting);
        adapter = new MySettingRecyclerViewAdapter(SettingContent.SETTING_ITEMS, this);
        lstSetting.setLayoutManager(new LinearLayoutManager(this));
        lstSetting.setAdapter(adapter);
    }


    @Override
    public void onItemClickListener(SettingModel item) {
        Intent intent = null;
        switch (item.getName()) {
            case "Basic Information":
                intent = new Intent(SettingActivity.this, BasicInformationActivity.class);
                break;
            case "Device Information":
                intent = new Intent(SettingActivity.this, DeviceInformation.class);
                break;
            case "Setting Information":
                intent = new Intent(SettingActivity.this, SettingInformationActivity.class);
                break;
            case "App Information":
                intent = new Intent(SettingActivity.this, AppInformationActivity.class);
                break;
        }
        if (intent != null){
            intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(intent);
        }
    }
}
