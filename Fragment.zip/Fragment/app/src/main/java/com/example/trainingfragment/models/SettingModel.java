package com.example.trainingfragment.models;

public class SettingModel {
    private final int imageIcon;
    private final String name;
    private final String description;

    public SettingModel(int imageIcon, String name, String description) {
        this.imageIcon = imageIcon;
        this.name = name;
        this.description = description;
    }

    public int getImageIcon() {
        return imageIcon;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }
}
